package com.dianping.cat.helper;

public class Chinese {

	public static final String RESPONSE_TIME = "响应时间";

	public static final String EXCEPTION_COUNT = "错误数";

	public static final String TOTAL_COUNT = "访问量";

	public static final String EXCEPTION_INFO = "异常信息";

	public static final String ZABBIX_ERROR = "Zabbix告警";

	public static final String Suffix_SUM = "(总和)";

	public static final String Suffix_COUNT = "(次数)";

	public static final String Suffix_AVG = "(平均)";

	public static final String CURRENT_VALUE = "当前值";

	public static final String BASELINE_VALUE = "基线值";

	public static final String ONEDAY_VALUE = "前一天值";

	public static final String ONEWEEK_VALUE = "前一个星期值";

}
